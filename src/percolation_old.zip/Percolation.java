import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 * Created by Vasiliy Kylik on 08.10.2017.
 * Hint: At minimum, you'll need to store the grid size,
 * which sites are open, and which sites are connected to which other sites.
 * The last of these is exactly what the union-find data structure is designed for.
 */
public class Percolation {

    private int n;
    private WeightedQuickUnionUF quickUnionUF;
    private byte[][] open;
    private int num;

    // create n-by-n grid, with all sites blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Input error n must > 0 " + n);
        }
        this.n = n + 1;
        quickUnionUF = new WeightedQuickUnionUF(this.n * this.n);
        open = new byte[this.n][this.n];
    }

    // open site (row, col) if it is not open already
    public void open(int row, int col) {
        validate(row, col);
        if (isOpen(row, col)) return;
        open[row][col] = 1;
        num++;
        if (row == n - 1) open[row][col] = 2;
        if (row == 1) {
            quickUnionUF.union(0, row * n + col);
            if (open[row][col] == 2) open[0][0] = 2;
        }
        if (row - 1 < n && isOpen(row - 1, col)) {
            update(row - 1, col, row, col);
        }
        if (row + 1 < n && isOpen(row + 1, col)) {
            update(row + 1, col, row, col);
        }
        if (col - 1 > 0 && isOpen(row, col - 1)) {
            update(row, col - 1, row, col);
        }
        if (col + 1 < n && isOpen(row, col + 1)) {
            update(row, col + 1, row, col);
        }
    }

    private void update(int i1, int i2, int j1, int j2) {
        int p = quickUnionUF.find(i1 * n + j1);
        int q = quickUnionUF.find(i2 * n + j2);
        if (open[p / n][p % n] == 2 || open[q / n][q % n] == 2) {
            int t = quickUnionUF.find(i2 * n + j2);
            open[t / n][t % n] = 2;
        }
    }

    // is site (row, col) open?
    public boolean isOpen(int row, int col) {
        validate(row, col);
        return open[row][col] > 0;
    }

    // is site (row, col) full?
    public boolean isFull(int row, int col) {
        validate(row, col);
        return open[row][col] > 0 && quickUnionUF.connected(0, row * n + col);
    }

    // number of open sites
    public int numberOfOpenSites() {
        return num;
    }

    // does the system percolate?
    public boolean percolates() {
        int root = quickUnionUF.find(0);
        return open[root / n][root % n] == 2;
    }


    private void validate(int row, int col) {
        if (row <= 0 || row >= n) {
            throw new IndexOutOfBoundsException("Input error : row index out of bounds");
        }
        if (col <= 0 || col >= n) {
            throw new IndexOutOfBoundsException("Input error : col index out of bounds");
        }
    }

    // test client (optional)
    public static void main(String[] args) {
        In input = new In(args[0]);
        int n = input.readInt();
        Percolation percolation = new Percolation(n);
        boolean isPercolated = false;
        int count = 0;
        while (!input.isEmpty()) {
            int row = input.readInt();
            int col = input.readInt();
            if (!percolation.isOpen(row, col)) {
                count++;
            }
            percolation.open(row, col);
            isPercolated = percolation.percolates();
            if (isPercolated) {
                break;
            }
        }
        StdOut.println(count + " open sites");
        if (isPercolated) {
            StdOut.println("System percolates");
        } else {
            StdOut.println("System does not percolates");
        }
    }
}

